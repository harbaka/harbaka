const gameContainer = document.getElementById("game");

const COLORS = [
  "red",
  "blue",
  "green",
  "orange",
  "purple",
  "red",
  "blue",
  "green",
  "orange",
  "purple"
];

// here is a helper function to shuffle an array
// it returns the same array with values shuffled
// it is based on an algorithm called Fisher Yates if you want ot research more
function shuffle(array) {
  let counter = array.length;

  // While there are elements in the array
  while (counter > 0) {
    // Pick a random index
    let index = Math.floor(Math.random() * counter);

    // Decrease counter by 1
    counter--;

    // And swap the last element with it
    let temp = array[counter];
    array[counter] = array[index];
    array[index] = temp;
  }

  return array;
}

let shuffledColors = shuffle(COLORS);
let colorClicked=[],i=0,clickCount=0;;
let idNo=0;
let myIdAr=[],j=0;
let myid;
let scoreCount=0;
let lowestScore;
let noOne;
let realId;

// this function loops over the array of colors
// it creates a new div and gives it a class with the value of the color
// it also adds an event listener for a click for each card
function createDivsForColors(colorArray) {
  for (let color of colorArray) {
      
      idNo++;
      let cardId='card'+idNo;
    
    // create a new div
    const newDiv = document.createElement("div");
    //creat id
    newDiv.setAttribute('id',cardId)
    
    

    // give it a class attribute for the value we are looping over
   // newDiv.classList.add(color);
  
    // call a function handleCardClick when a div is clicked on
    newDiv.addEventListener("click", handleCardClick);
    
    newDiv.addEventListener('click',function (e)
    { 
      //background change
   colorClicked[i++]=newDiv.style.backgroundColor=color;

   clickCount++;
   label.innerText=scoreCount++;
   //scoreCount++;

   console.log(scoreCount);
    myid=e.target.id;
    myIdAr[j++]=myid;
    disableCard(myIdAr);
     realId='#'+myid;

    console.log(myid);
  
   
    noOne=document.querySelector(realId)
    //noOne.classList.remove('defalt')
   
   if(colorClicked[0]===colorClicked[1] && clickCount===2)
   {
       clickCount=0;
       i=0;
     
     
      console.log('apperently win');
      
   }
   else{
     if(i===2)
    {
     setInterval(function(){
     // location.reload();
     location.reload();
    
    
      
     

     },1000)
    } 

   }
    
   console.log(colorClicked);
     
    })

     // append the div to the element with an id of game
    gameContainer.append(newDiv);
    //newDiv.append.(newClass);
  }
}


//let overCount=2;
const div=document.querySelector('#game');
// TODO: Implement this function!
function handleCardClick(event) {
  // you can use event.target to see which element was clicked
  
  console.log("you just clicked" + event.target );

}

// when the DOM loads
//createDivsForColors(shuffledColors);
//creating start button
const startButtonId=document.querySelector('#start');
console.log(startButtonId);
const startButton=document.createElement('button');
startButton.innerText="START";
startButtonId.append(startButton);
//event listner for Start button
startButton.addEventListener('click',function(e){
  createDivsForColors(shuffledColors);
});

//creating restart button
const restartButtonId=document.querySelector('#restart')
const restartButton=document.createElement('button');
restartButton.innerText="RESTART";
restartButtonId.append(restartButton)

const reload =restartButton.addEventListener('click',function(e){
  //location.reload(); 
  createDivsForColors(shuffledColors)
})

//pass score to textbox
const label=document.querySelector('label');
label.innerText=scoreCount;




function disableCard(myIdAr)
{ if(myIdAr.length>=2)
  {
    for(let i=0;i<myIdAr.length;i++)
     {
       for(let j=i+1;j<myIdAr.length;j++)
        {
          if(myIdAr[i] === myIdAr[j])  
          {
            console.log("you cant continue...");
            
              location.reload();
             //reload;
             
          }
        }
    
     }
  }
  
}